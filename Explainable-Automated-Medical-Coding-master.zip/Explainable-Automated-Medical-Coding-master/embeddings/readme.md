The two ```.py``` files show how to train word and label embeddings with the Python Gensim package. We used the Continuous Bag of Words algorihtm with negative sampling and set the window size as 5, mininum frequency threshold (```min_count```) as 0.

The pre-trained word and label embedding files are available at Onedrive, [link](https://onedrive.live.com/?authkey=%21ACZVuCnEV2zDKow&id=22F95C44F607EC5B%21255141&cid=22F95C44F607EC5B).
